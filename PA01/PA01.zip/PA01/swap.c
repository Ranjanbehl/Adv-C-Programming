// * DO NOT MODIFY THIS FILE * 
// If you modify this file, your program may be incompatible
// in grading and you may lose points.
// 
void swap(int * a, int * b)
{
  int t = * a; // temporary
  * a = * b;
  * b = t;
}
